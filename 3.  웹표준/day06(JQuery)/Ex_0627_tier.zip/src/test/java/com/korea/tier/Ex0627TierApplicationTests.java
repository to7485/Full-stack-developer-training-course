package com.korea.tier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex0627TierApplicationTests {

	@Test
	void contextLoads() {
	}

}
