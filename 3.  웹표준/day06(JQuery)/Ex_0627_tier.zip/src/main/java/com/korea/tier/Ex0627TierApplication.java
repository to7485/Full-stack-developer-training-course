package com.korea.tier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex0627TierApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex0627TierApplication.class, args);
	}

}
